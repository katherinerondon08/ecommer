import React, { useState } from 'react';
import OnboardingWizard from './components/OnboardingWizard';
import AIProductOptimizer from './components/AIProductOptimizer';
import LogisticsDashboard from './components/LogisticsDashboard';
import AffiliateNetwork from './components/AffiliateNetwork';
import LayoutHeader from './components/LayoutHeader';
import LayoutFooter from './components/LayoutFooter';

const App = () => {
  const [currentView, setCurrentView] = useState('onboarding');

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      <LayoutHeader />
      <main className="flex-grow py-8">
        <div className="container mx-auto px-4">
          <div className="flex mb-6 space-x-2">
            <button
              onClick={() => setCurrentView('onboarding')}
              className={`px-4 py-2 rounded-lg ${currentView === 'onboarding' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}
            >
              Onboarding
            </button>
            <button
              onClick={() => setCurrentView('optimizer')}
              className={`px-4 py-2 rounded-lg ${currentView === 'optimizer' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}
            >
              Optimizador IA
            </button>
            <button
              onClick={() => setCurrentView('logistics')}
              className={`px-4 py-2 rounded-lg ${currentView === 'logistics' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}
            >
              Logística
            </button>
            <button
              onClick={() => setCurrentView('affiliate')}
              className={`px-4 py-2 rounded-lg ${currentView === 'affiliate' ? 'bg-blue-600 text-white' : 'bg-white text-gray-700'}`}
            >
              Afiliados
            </button>
          </div>

          {currentView === 'onboarding' && <OnboardingWizard />}
          {currentView === 'optimizer' && <AIProductOptimizer />}
          {currentView === 'logistics' && <LogisticsDashboard />}
          {currentView === 'affiliate' && <AffiliateNetwork />}
        </div>
      </main>
      <LayoutFooter />
    </div>
  );
};

export default App;

// DONE
const trackingData = {
  "RR123456789": {
    orderNumber: "RR123456789",
    status: "en_camino",
    estimatedDelivery: "2023-12-15",
    carrier: "RR Express",
    steps: [
      { 
        status: "orden_recibida", 
        date: "2023-12-10 09:30", 
        location: "Centro de distribución principal",
        completed: true
      },
      { 
        status: "en_proceso", 
        date: "2023-12-11 14:15", 
        location: "Centro de distribución principal",
        completed: true
      },
      { 
        status: "en_camino", 
        date: "2023-12-12 10:00", 
        location: "En ruta a tu zona",
        completed: true
      },
      { 
        status: "reparto", 
        date: null, 
        location: "Próximamente",
        completed: false
      },
      { 
        status: "entregado", 
        date: null, 
        location: "Próximamente",
        completed: false
      }
    ],
    currentLocation: {
      lat: 19.4326,
      lng: -99.1332,
      address: "Av. Insurgentes Sur 123, CDMX"
    },
    driver: {
      name: "Juan Pérez",
      phone: "+525512345678",
      vehicle: "Moto RR-2023"
    }
  }
};

export default trackingData;
import React from 'react';

const TrackingMap = ({ location, driver }) => {
  // En una implementación real, aquí iría la integración con Google Maps o similar
  // Este es un placeholder visual con SVG
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 mb-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-4">Ubicación actual</h3>
      <div className="relative h-64 bg-gray-100 rounded-lg overflow-hidden">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
          {/* Mapa de fondo simplificado */}
          <rect width="100" height="100" fill="#e5e7eb" />
          <path d="M20,20 L80,20 L80,80 L20,80 Z" fill="#f3f4f6" stroke="#9ca3af" strokeWidth="0.5" />
          <path d="M30,30 L70,30 L70,70 L30,70 Z" fill="#e5e7eb" stroke="#9ca3af" strokeWidth="0.5" />
          <path d="M40,40 L60,40 L60,60 L40,60 Z" fill="#d1d5db" stroke="#6b7280" strokeWidth="0.5" />
          
          {/* Ruta */}
          <path d="M10,50 Q50,10 90,50" stroke="#3b82f6" strokeWidth="1.5" fill="none" strokeDasharray="5,5" />
          
          {/* Punto de ubicación actual */}
          <circle cx="50" cy="50" r="3" fill="#ef4444" stroke="#fff" strokeWidth="1" />
          <text x="50" y="45" textAnchor="middle" fontSize="3" fill="#ef4444">Tu paquete</text>
        </svg>
        <div className="absolute bottom-4 left-4 right-4 bg-white p-3 rounded-lg shadow-sm">
          <p className="text-sm font-medium text-gray-900">{location.address}</p>
          <p className="text-xs text-gray-500 mt-1">
            Última actualización: {new Date().toLocaleTimeString()}
          </p>
        </div>
      </div>
      <div className="mt-4 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm font-medium text-gray-900">Repartidor asignado</p>
        <div className="flex items-center mt-2">
          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-600 mr-3">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
            </svg>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">{driver.name}</p>
            <p className="text-xs text-gray-500">{driver.vehicle} • {driver.phone}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackingMap;
import React from 'react';

const LayoutHeader = () => {
  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7"></path>
            </svg>
          </div>
          <h1 className="text-xl font-bold text-gray-900">RR.LogisticSolutions</h1>
        </div>
        <nav className="hidden md:flex space-x-8">
          <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">Inicio</a>
          <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">Servicios</a>
          <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">Afiliación</a>
          <a href="#" className="text-gray-700 hover:text-blue-600 transition-colors">Seguimiento</a>
        </nav>
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
          Iniciar Sesión
        </button>
      </div>
    </header>
  );
};

export default LayoutHeader;
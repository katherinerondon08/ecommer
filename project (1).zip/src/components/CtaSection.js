import React from 'react';

const CtaSection = () => {
  return (
    <section className="py-16 bg-blue-600 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-3xl font-bold mb-6">¿Listo para transformar tu logística?</h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto">
          Únete a cientos de empresas que ya están optimizando sus procesos con RR.LogisticSolutions
        </p>
        <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
          <button className="bg-white text-blue-600 px-8 py-3 rounded-lg hover:bg-gray-100 transition-colors font-semibold">
            Comenzar ahora
          </button>
          <button className="border border-white text-white px-8 py-3 rounded-lg hover:bg-blue-700 transition-colors font-semibold">
            Hablar con un asesor
          </button>
        </div>
      </div>
    </section>
  );
};

export default CtaSection;
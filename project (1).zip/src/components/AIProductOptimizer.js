import React, { useState } from 'react';

const AIProductOptimizer = () => {
  const [product, setProduct] = useState({
    title: '',
    description: '',
    price: '',
    category: ''
  });
  const [optimized, setOptimized] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setProduct({
      ...product,
      [e.target.name]: e.target.value
    });
  };

  const handleOptimize = () => {
    setLoading(true);
    // Simulación de llamada a IA
    setTimeout(() => {
      setOptimized({
        title: `${product.title} | ${product.category} | Calidad Premium`,
        description: `Descubre nuestro increíble ${product.title.toLowerCase()}. ${product.description} ¡Envío rápido y seguro! Compra ahora al mejor precio.`,
        tags: [`${product.category}`, "envío rápido", "calidad garantizada"]
      });
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">Optimizador de Productos con IA</h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h4 className="text-lg font-medium text-gray-900">Información original</h4>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Título del producto</label>
            <input
              type="text"
              name="title"
              value={product.title}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Ej: Camiseta de algodón"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descripción</label>
            <textarea
              name="description"
              value={product.description}
              onChange={handleChange}
              rows={3}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Describe tu producto"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Categoría</label>
            <input
              type="text"
              name="category"
              value={product.category}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Ej: Ropa"
            />
          </div>
          <button
            onClick={handleOptimize}
            disabled={!product.title || loading}
            className={`px-4 py-2 rounded-lg ${!product.title || loading ? 'bg-gray-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
          >
            {loading ? 'Optimizando...' : 'Optimizar con IA'}
          </button>
        </div>

        <div className="space-y-4">
          <h4 className="text-lg font-medium text-gray-900">Resultado optimizado</h4>
          {optimized ? (
            <>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm font-medium text-gray-700 mb-1">Título optimizado (SEO)</p>
                <p className="text-gray-900">{optimized.title}</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm font-medium text-gray-700 mb-1">Descripción mejorada</p>
                <p className="text-gray-900">{optimized.description}</p>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <p className="text-sm font-medium text-gray-700 mb-1">Etiquetas sugeridas</p>
                <div className="flex flex-wrap gap-2 mt-2">
                  {optimized.tags.map((tag, index) => (
                    <span key={index} className="px-2 py-1 bg-white text-blue-600 text-xs rounded-full border border-blue-200">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <div className="bg-gray-50 p-8 rounded-lg text-center">
              <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
              </svg>
              <p className="mt-2 text-sm text-gray-600">
                Ingresa la información de tu producto y haz clic en "Optimizar con IA"
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AIProductOptimizer;
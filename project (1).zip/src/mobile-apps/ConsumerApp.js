import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';

const ConsumerApp = () => {
  const [activeTab, setActiveTab] = useState('home');
  const [businesses] = useState([
    { id: '1', name: 'Panadería Doña Rosa', category: 'Alimentos', rating: 4.8, deliveryTime: '20-30 min', image: require('./assets/bakery.jpg') },
    { id: '2', name: 'Artesanías El Buen Pastor', category: 'Artesanías', rating: 4.9, deliveryTime: '1-2 días', image: require('./assets/crafts.jpg') },
    { id: '3', name: 'Frutas y Verduras Frescas', category: 'Alimentos', rating: 4.7, deliveryTime: '30-45 min', image: require('./assets/groceries.jpg') }
  ]);

  const [featuredProducts] = useState([
    { id: 'p1', name: 'Pan Integral Artesanal', price: '$35', business: 'Panadería Doña Rosa', image: require('./assets/bread.jpg') },
    { id: 'p2', name: 'Miel de Abeja Natural', price: '$120', business: 'Frutas y Verduras', image: require('./assets/honey.jpg') },
    { id: 'p3', name: 'Jarrón de Barro Negro', price: '$280', business: 'Artesanías', image: require('./assets/vase.jpg') }
  ]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View style={styles.locationSelector}>
          <Image source={require('./assets/location-pin.png')} style={styles.locationIcon} />
          <Text style={styles.locationText}>Enviar a: Casa • Av. Reforma 123</Text>
          <Image source={require('./assets/chevron-down.png')} style={styles.chevronIcon} />
        </View>
      </View>

      <View style={styles.searchBar}>
        <Image source={require('./assets/search-icon.png')} style={styles.searchIcon} />
        <Text style={styles.searchText}>Buscar productos o negocios...</Text>
      </View>

      {activeTab === 'home' && (
        <FlatList
          data={[1]} // Solo un item para el scroll
          renderItem={() => (
            <View style={styles.content}>
              <Text style={styles.sectionTitle}>Negocios Destacados</Text>
              <FlatList
                horizontal
                data={businesses}
                keyExtractor={item => item.id}
                renderItem={({ item }) => (
                  <TouchableOpacity style={styles.businessCard}>
                    <Image source={item.image} style={styles.businessImage} />
                    <View style={styles.businessInfo}>
                      <Text style={styles.businessName}>{item.name}</Text>
                      <Text style={styles.businessCategory}>{item.category}</Text>
                      <View style={styles.businessMeta}>
                        <Image source={require('./assets/star-icon.png')} style={styles.starIcon} />
                        <Text style={styles.businessRating}>{item.rating}</Text>
                        <Text style={styles.businessDelivery}>• {item.deliveryTime}</Text>
                      </View>
                    </View>
                  </TouchableOpacity>
                )}
                contentContainerStyle={styles.horizontalList}
              />

              <Text style={styles.sectionTitle}>Productos Recomendados</Text>
              <FlatList
                horizontal
                data={featuredProducts}
                keyExtractor={item => item.id}
                renderItem={({ item }) => (
                  <TouchableOpacity style={styles.productCard}>
                    <Image source={item.image} style={styles.productImage} />
                    <Text style={styles.productName}>{item.name}</Text>
                    <Text style={styles.productPrice}>{item.price}</Text>
                    <Text style={styles.productBusiness}>{item.business}</Text>
                  </TouchableOpacity>
                )}
                contentContainerStyle={styles.horizontalList}
              />

              <Text style={styles.sectionTitle}>Categorías</Text>
              <View style={styles.categoriesGrid}>
                <TouchableOpacity style={styles.categoryCard}>
                  <View style={[styles.categoryIcon, { backgroundColor: '#fef3c7' }]}>
                    <Image source={require('./assets/food-icon.png')} style={styles.categoryImage} />
                  </View>
                  <Text style={styles.categoryText}>Alimentos</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.categoryCard}>
                  <View style={[styles.categoryIcon, { backgroundColor: '#dbeafe' }]}>
                    <Image source={require('./assets/craft-icon.png')} style={styles.categoryImage} />
                  </View>
                  <Text style={styles.categoryText}>Artesanías</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.categoryCard}>
                  <View style={[styles.categoryIcon, { backgroundColor: '#d1fae5' }]}>
                    <Image source={require('./assets/service-icon.png')} style={styles.categoryImage} />
                  </View>
                  <Text style={styles.categoryText}>Servicios</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.categoryCard}>
                  <View style={[styles.categoryIcon, { backgroundColor: '#ede9fe' }]}>
                    <Image source={require('./assets/more-icon.png')} style={styles.categoryImage} />
                  </View>
                  <Text style={styles.categoryText}>Ver más</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}

      <View style={styles.navigationBar}>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => setActiveTab('home')}
        >
          <Image 
            source={require('./assets/home-icon.png')} 
            style={[styles.navIcon, activeTab === 'home' && styles.activeNavIcon]} 
          />
          <Text style={[styles.navText, activeTab === 'home' && styles.activeNavText]}>Inicio</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => setActiveTab('search')}
        >
          <Image 
            source={require('./assets/search-nav-icon.png')} 
            style={[styles.navIcon, activeTab === 'search' && styles.activeNavIcon]} 
          />
          <Text style={[styles.navText, activeTab === 'search' && styles.activeNavText]}>Buscar</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => setActiveTab('orders')}
        >
          <Image 
            source={require('./assets/orders-icon.png')} 
            style={[styles.navIcon, activeTab === 'orders' && styles.activeNavIcon]} 
          />
          <Text style={[styles.navText, activeTab === 'orders' && styles.activeNavText]}>Pedidos</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.navButton}
          onPress={() => setActiveTab('profile')}
        >
          <Image 
            source={require('./assets/profile-nav-icon.png')} 
            style={[styles.navIcon, activeTab === 'profile' && styles.activeNavIcon]} 
          />
          <Text style={[styles.navText, activeTab === 'profile' && styles.activeNavText]}>Perfil</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'white'
  },
  header: {
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 15,
    borderBottomWidth: 1,
    borderBottomColor: '#f3f4f6'
  },
  locationSelector: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  locationIcon: {
    width: 20,
    height: 20,
    marginRight: 8,
    tintColor: '#ef4444'
  },
  locationText: {
    fontSize: 16,
    fontWeight: '500',
    color: '#1f2937'
  },
  chevronIcon: {
    width: 16,
    height: 16,
    marginLeft: 5,
    tintColor: '#6b7280'
  },
  searchBar: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f3f4f6',
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 12,
    marginHorizontal: 20,
    marginVertical: 15
  },
  searchIcon: {
    width: 18,
    height: 18,
    marginRight: 10,
    tintColor: '#9ca3af'
  },
  searchText: {
    fontSize: 14,
    color: '#9ca3af'
  },
  content: {
    padding: 20,
    paddingBottom: 80
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 15
  },
  horizontalList: {
    paddingBottom: 10
  },
  businessCard: {
    width: 220,
    marginRight: 15,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'white',
    elevation: 2
  },
  businessImage: {
    width: '100%',
    height: 120
  },
  businessInfo: {
    padding: 12
  },
  businessName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 3
  },
  businessCategory: {
    fontSize: 13,
    color: '#6b7280',
    marginBottom: 8
  },
  businessMeta: {
    flexDirection: 'row',
    alignItems: 'center'
  },
  starIcon: {
    width: 14,
    height: 14,
    marginRight: 4,
    tintColor: '#f59e0b'
  },
  businessRating: {
    fontSize: 13,
    color: '#1f2937',
    marginRight: 8
  },
  businessDelivery: {
    fontSize: 13,
    color: '#6b7280'
  },
  productCard: {
    width: 150,
    marginRight: 15
  },
  productImage: {
    width: '100%',
    height: 150,
    borderRadius: 10,
    marginBottom: 10,
    backgroundColor: '#f3f4f6'
  },
  productName: {
    fontSize: 14,
    fontWeight: '500',
    color: '#1f2937',
    marginBottom: 3
  },
  productPrice: {
    fontSize: 15,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 3
  },
  productBusiness: {
    fontSize: 12,
    color: '#6b7280'
  },
  categoriesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between'
  },
  categoryCard: {
    width: '48%',
    alignItems: 'center',
    marginBottom: 15
  },
  categoryIcon: {
    width: 70,
    height: 70,
    borderRadius: 35,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8
  },
  categoryImage: {
    width: 30,
    height: 30,
    tintColor: '#1f2937'
  },
  categoryText: {
    fontSize: 14,
    color: '#1f2937',
    fontWeight: '500'
  },
  navigationBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'white',
    paddingVertical: 12,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb'
  },
  navButton: {
    alignItems: 'center'
  },
  navIcon: {
    width: 24,
    height: 24,
    marginBottom: 5,
    tintColor: '#9ca3af'
  },
  activeNavIcon: {
    tintColor: '#4f46e5'
  },
  navText: {
    fontSize: 12,
    color: '#9ca3af'
  },
  activeNavText: {
    color: '#4f46e5'
  }
});

export default ConsumerApp;

// DONE
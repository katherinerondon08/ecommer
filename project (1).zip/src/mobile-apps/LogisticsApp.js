import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';

const LogisticsApp = () => {
  const [currentDelivery, setCurrentDelivery] = useState({
    id: 'DEL-10025',
    customer: 'María González',
    address: 'Av. Reforma 123, Int 45, Col. Centro',
    items: 3,
    distance: '2.5 km',
    payment: '$245',
    status: 'in_progress'
  });

  const handleStatusChange = () => {
    setCurrentDelivery(prev => ({
      ...prev,
      status: prev.status === 'in_progress' ? 'delivered' : 'in_progress'
    }));
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>RR.LogisticSolutions</Text>
        <Text style={styles.headerSubtitle}>Repartidor: Juan Pérez</Text>
      </View>

      <View style={styles.statusIndicator}>
        <View style={styles.statusStep}>
          <View style={[styles.statusDot, styles.activeDot]} />
          <Text style={styles.statusText}>Recogido</Text>
        </View>
        <View style={styles.statusLine} />
        <View style={styles.statusStep}>
          <View style={[styles.statusDot, currentDelivery.status !== 'pending' ? styles.activeDot : null]} />
          <Text style={styles.statusText}>En camino</Text>
        </View>
        <View style={styles.statusLine} />
        <View style={styles.statusStep}>
          <View style={[styles.statusDot, currentDelivery.status === 'delivered' ? styles.activeDot : null]} />
          <Text style={styles.statusText}>Entregado</Text>
        </View>
      </View>

      <View style={styles.deliveryCard}>
        <Text style={styles.deliveryId}>Entrega #{currentDelivery.id}</Text>
        
        <View style={styles.customerInfo}>
          <Image 
            source={require('./assets/user-icon.png')} 
            style={styles.customerImage}
          />
          <View>
            <Text style={styles.customerName}>{currentDelivery.customer}</Text>
            <Text style={styles.deliveryDetails}>{currentDelivery.items} artículos • {currentDelivery.distance}</Text>
          </View>
        </View>

        <View style={styles.deliveryAddress}>
          <Image 
            source={require('./assets/location-icon.png')} 
            style={styles.addressIcon}
          />
          <Text style={styles.addressText}>{currentDelivery.address}</Text>
        </View>

        <View style={styles.paymentInfo}>
          <Text style={styles.paymentText}>Monto a cobrar:</Text>
          <Text style={styles.paymentAmount}>{currentDelivery.payment}</Text>
        </View>

        <TouchableOpacity 
          style={[
            styles.actionButton,
            currentDelivery.status === 'delivered' ? styles.completedButton : null
          ]}
          onPress={handleStatusChange}
        >
          <Text style={styles.actionButtonText}>
            {currentDelivery.status === 'delivered' ? 'Entrega Completada' : 'Marcar como Entregado'}
          </Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.secondaryButton}>
          <Text style={styles.secondaryButtonText}>Problema con la entrega</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.navigationBar}>
        <TouchableOpacity style={styles.navButton}>
          <Image source={require('./assets/home-icon.png')} style={styles.navIcon} />
          <Text style={styles.navText}>Inicio</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton}>
          <Image source={require('./assets/history-icon.png')} style={styles.navIcon} />
          <Text style={styles.navText}>Historial</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton}>
          <Image source={require('./assets/stats-icon.png')} style={styles.navIcon} />
          <Text style={styles.navText}>Estadísticas</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navButton}>
          <Image source={require('./assets/profile-icon.png')} style={styles.navIcon} />
          <Text style={styles.navText}>Perfil</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f4f6'
  },
  header: {
    backgroundColor: '#111827',
    padding: 20,
    paddingTop: 50,
    paddingBottom: 25
  },
  headerTitle: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 5
  },
  headerSubtitle: {
    color: '#9ca3af',
    fontSize: 14
  },
  statusIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: 25,
    paddingHorizontal: 20
  },
  statusStep: {
    alignItems: 'center',
    width: 80
  },
  statusDot: {
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#d1d5db',
    marginBottom: 5
  },
  activeDot: {
    backgroundColor: '#10b981'
  },
  statusLine: {
    height: 2,
    flex: 1,
    backgroundColor: '#d1d5db',
    marginHorizontal: -5
  },
  statusText: {
    fontSize: 12,
    color: '#6b7280',
    textAlign: 'center'
  },
  deliveryCard: {
    backgroundColor: 'white',
    marginHorizontal: 20,
    borderRadius: 12,
    padding: 20,
    elevation: 3
  },
  deliveryId: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 15
  },
  customerInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20
  },
  customerImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 15,
    backgroundColor: '#e5e7eb'
  },
  customerName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 3
  },
  deliveryDetails: {
    fontSize: 13,
    color: '#6b7280'
  },
  deliveryAddress: {
    flexDirection: 'row',
    backgroundColor: '#f9fafb',
    borderRadius: 8,
    padding: 15,
    marginBottom: 20
  },
  addressIcon: {
    width: 20,
    height: 20,
    marginRight: 10,
    tintColor: '#6b7280'
  },
  addressText: {
    flex: 1,
    fontSize: 14,
    color: '#4b5563'
  },
  paymentInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 25
  },
  paymentText: {
    fontSize: 16,
    color: '#6b7280'
  },
  paymentAmount: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#1f2937'
  },
  actionButton: {
    backgroundColor: '#10b981',
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10
  },
  completedButton: {
    backgroundColor: '#e5e7eb'
  },
  actionButtonText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600'
  },
  secondaryButton: {
    padding: 16,
    borderRadius: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#e5e7eb'
  },
  secondaryButtonText: {
    color: '#ef4444',
    fontSize: 16,
    fontWeight: '600'
  },
  navigationBar: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    backgroundColor: 'white',
    paddingVertical: 10,
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb'
  },
  navButton: {
    alignItems: 'center',
    padding: 5
  },
  navIcon: {
    width: 24,
    height: 24,
    marginBottom: 5,
    tintColor: '#6b7280'
  },
  navText: {
    fontSize: 12,
    color: '#6b7280'
  }
});

export default LogisticsApp;
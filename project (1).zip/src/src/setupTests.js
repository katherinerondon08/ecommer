// Configuración básica para evitar errores en el build
// Este archivo puede estar vacío pero debe existir
import React from 'react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      quote: "RR.LogisticSolutions transformó nuestro negocio. Ahora nuestros clientes reciben sus pedidos más rápido y con mejor seguimiento.",
      author: "María González",
      role: "CEO, ModaExpress"
    },
    {
      quote: "La integración con nuestra tienda online fue impecable. El sistema de afiliados ha aumentado nuestras ventas en un 40%.",
      author: "Carlos Mendoza",
      role: "Director, TechGadgets"
    },
    {
      quote: "Nunca había visto un sistema logístico tan completo. La app móvil es increíble para gestionar nuestros repartos.",
      author: "Laura Jiménez",
      role: "Logística, FreshMarket"
    }
  ];

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Lo que dicen nuestros clientes</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Empresas que han transformado su logística con nuestra plataforma.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-xl">
              <div className="mb-4">
                <svg className="w-8 h-8 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                </svg>
              </div>
              <p className="text-gray-700 mb-6">"{testimonial.quote}"</p>
              <div>
                <p className="font-semibold text-gray-900">{testimonial.author}</p>
                <p className="text-gray-600">{testimonial.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
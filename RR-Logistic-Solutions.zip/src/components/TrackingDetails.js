import React from 'react';

const TrackingDetails = ({ order }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h3 className="text-xl font-semibold text-gray-900 mb-6">Detalles del pedido</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h4 className="text-sm font-medium text-gray-500 mb-2">Número de seguimiento</h4>
          <p className="text-lg font-medium text-gray-900">{order.orderNumber}</p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-gray-500 mb-2">Transportista</h4>
          <p className="text-lg font-medium text-gray-900">{order.carrier}</p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-gray-500 mb-2">Fecha estimada de entrega</h4>
          <p className="text-lg font-medium text-gray-900">
            {new Date(order.estimatedDelivery).toLocaleDateString()}
          </p>
        </div>
        <div>
          <h4 className="text-sm font-medium text-gray-500 mb-2">Estado actual</h4>
          <p className="text-lg font-medium text-blue-600">
            {order.status === 'entregado' ? 'Entregado' : 'En tránsito'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default TrackingDetails;
import React, { useState } from 'react';

const LogisticsDashboard = () => {
  const [activeTab, setActiveTab] = useState('deliveries');
  const [deliveries] = useState([
    { id: 1, order: '#ORD-1001', status: 'en_camino', customer: 'María González', driver: 'Juan Pérez', eta: '30 min' },
    { id: 2, order: '#ORD-1002', status: 'pendiente', customer: 'Carlos Mendoza', driver: 'Asignar', eta: '' },
    { id: 3, order: '#ORD-1003', status: 'entregado', customer: 'Laura Jiménez', driver: 'Pedro Sánchez', eta: 'Entregado' }
  ]);

  const statusStyles = {
    pendiente: 'bg-yellow-100 text-yellow-800',
    en_camino: 'bg-blue-100 text-blue-800',
    entregado: 'bg-green-100 text-green-800'
  };

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="border-b border-gray-200">
        <nav className="flex -mb-px">
          <button
            onClick={() => setActiveTab('deliveries')}
            className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${activeTab === 'deliveries' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >
            Entregas
          </button>
          <button
            onClick={() => setActiveTab('drivers')}
            className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${activeTab === 'drivers' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >
            Repartidores
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`py-4 px-6 text-center border-b-2 font-medium text-sm ${activeTab === 'reports' ? 'border-blue-500 text-blue-600' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'}`}
          >
            Reportes
          </button>
        </nav>
      </div>

      <div className="p-6">
        {activeTab === 'deliveries' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-lg font-medium text-gray-900">Gestión de entregas</h3>
              <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
                Nueva entrega
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Pedido</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cliente</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Repartidor</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">ETA</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {deliveries.map((delivery) => (
                    <tr key={delivery.id}>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{delivery.order}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{delivery.customer}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{delivery.driver}</td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 text-xs font-medium rounded-full ${statusStyles[delivery.status]}`}>
                          {delivery.status === 'en_camino' ? 'En camino' : delivery.status === 'pendiente' ? 'Pendiente' : 'Entregado'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{delivery.eta}</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <button className="text-blue-600 hover:text-blue-900 mr-3">Ver</button>
                        <button className="text-gray-600 hover:text-gray-900">Editar</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'drivers' && (
          <div className="text-center py-12">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path>
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900">Gestión de repartidores</h3>
            <p className="mt-1 text-sm text-gray-500">Aquí podrás administrar tu flota de repartidores.</p>
            <div className="mt-6">
              <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none">
                Agregar repartidor
              </button>
            </div>
          </div>
        )}

        {activeTab === 'reports' && (
          <div className="text-center py-12">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
            </svg>
            <h3 className="mt-2 text-lg font-medium text-gray-900">Reportes logísticos</h3>
            <p className="mt-1 text-sm text-gray-500">Genera reportes detallados de tus operaciones logísticas.</p>
            <div className="mt-6">
              <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none">
                Generar reporte
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LogisticsDashboard;
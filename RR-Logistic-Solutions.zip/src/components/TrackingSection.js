import React, { useState } from 'react';

const TrackingSection = () => {
  const [trackingNumber, setTrackingNumber] = useState('');

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto bg-white rounded-xl shadow-sm overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 bg-blue-600 p-8 text-white">
              <h2 className="text-2xl font-bold mb-4">Seguimiento en tiempo real</h2>
              <p className="mb-6">
                Ingresa tu número de seguimiento para conocer el estado actual de tu envío.
              </p>
              <div className="flex items-center">
                <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                </svg>
                <span>100% seguro y confiable</span>
              </div>
            </div>
            <div className="md:w-1/2 p-8">
              <div className="mb-6">
                <label htmlFor="tracking" className="block text-gray-700 mb-2">Número de seguimiento</label>
                <input
                  type="text"
                  id="tracking"
                  value={trackingNumber}
                  onChange={(e) => setTrackingNumber(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Ej: RR123456789"
                />
              </div>
              <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors">
                Rastrear envío
              </button>
              <div className="mt-4 text-center">
                <a href="#" className="text-blue-600 hover:underline">¿No tienes un número de seguimiento?</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TrackingSection;
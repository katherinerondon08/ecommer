import React, { useState } from 'react';

const OnboardingWizard = () => {
  const [step, setStep] = useState(1);
  const [businessData, setBusinessData] = useState({
    name: '',
    category: '',
    description: ''
  });

  const handleChange = (e) => {
    setBusinessData({
      ...businessData,
      [e.target.name]: e.target.value
    });
  };

  const nextStep = () => setStep(step + 1);
  const prevStep = () => setStep(step - 1);

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-md overflow-hidden p-6">
      <div className="flex justify-between mb-8">
        {[1, 2, 3, 4].map((item) => (
          <div key={item} className="flex flex-col items-center">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center 
              ${step >= item ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-600'}`}>
              {item}
            </div>
            <div className={`text-xs mt-2 ${step >= item ? 'text-blue-600' : 'text-gray-500'}`}>
              Paso {item}
            </div>
          </div>
        ))}
      </div>

      {step === 1 && (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-gray-900">Información básica de tu negocio</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nombre del negocio</label>
            <input
              type="text"
              name="name"
              value={businessData.name}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Ej: Panadería Doña Rosa"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Categoría</label>
            <select
              name="category"
              value={businessData.category}
              onChange={handleChange}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="">Selecciona una categoría</option>
              <option value="Alimentos">Alimentos</option>
              <option value="Artesanías">Artesanías</option>
              <option value="Servicios">Servicios</option>
            </select>
          </div>
          <div className="flex justify-end">
            <button
              onClick={nextStep}
              disabled={!businessData.name || !businessData.category}
              className={`px-6 py-2 rounded-lg ${!businessData.name || !businessData.category ? 'bg-gray-300 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'}`}
            >
              Siguiente
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-gray-900">Configuración inicial</h3>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Descripción del negocio</label>
            <textarea
              name="description"
              value={businessData.description}
              onChange={handleChange}
              rows={4}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Describe qué hace único tu negocio"
            />
          </div>
          <div className="flex justify-between">
            <button
              onClick={prevStep}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Anterior
            </button>
            <button
              onClick={nextStep}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Siguiente
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-gray-900">Sube tus productos</h3>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
            </svg>
            <p className="mt-2 text-sm text-gray-600">
              Arrastra tus imágenes aquí o haz clic para seleccionar archivos
            </p>
            <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm">
              Seleccionar archivos
            </button>
          </div>
          <div className="flex justify-between">
            <button
              onClick={prevStep}
              className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              Anterior
            </button>
            <button
              onClick={nextStep}
              className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Siguiente
            </button>
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="space-y-6 text-center">
          <svg className="mx-auto h-16 w-16 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path>
          </svg>
          <h3 className="text-2xl font-bold text-gray-900">¡Listo para comenzar!</h3>
          <p className="text-gray-600">
            Tu negocio <span className="font-semibold">{businessData.name}</span> está configurado y listo para recibir pedidos.
          </p>
          <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-medium">
            Ir al panel de control
          </button>
        </div>
      )}
    </div>
  );
};

export default OnboardingWizard;
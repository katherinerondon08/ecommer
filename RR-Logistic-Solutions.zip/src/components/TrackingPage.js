import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import TrackingStatus from './TrackingStatus';
import TrackingMap from './TrackingMap';
import TrackingDetails from './TrackingDetails';
import trackingData from '../mock/trackingData';

const TrackingPage = () => {
  const { trackingNumber } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    // Simulación de carga de datos
    const timer = setTimeout(() => {
      if (trackingData[trackingNumber]) {
        setOrder(trackingData[trackingNumber]);
      } else {
        setError('Número de seguimiento no encontrado');
      }
      setLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, [trackingNumber]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
          </svg>
          <h3 className="mt-2 text-lg font-medium text-gray-900">Error</h3>
          <p className="mt-1 text-gray-500">{error}</p>
          <div className="mt-6">
            <button
              onClick={() => window.history.back()}
              className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none"
            >
              Volver atrás
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900">Seguimiento de envío</h2>
          <p className="text-gray-600">Número de seguimiento: {trackingNumber}</p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <TrackingStatus status={order.status} steps={order.steps} />
            <TrackingMap location={order.currentLocation} driver={order.driver} />
          </div>
          <div className="lg:col-span-1">
            <TrackingDetails order={order} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrackingPage;
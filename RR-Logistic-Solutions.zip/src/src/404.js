import React from 'react';

const NotFoundPage = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">404 - Página no encontrada</h1>
        <p className="text-lg text-gray-600 mb-6">
          La página que estás buscando no existe o ha sido movida.
        </p>
        <a 
          href="/" 
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors inline-block"
        >
          Volver al inicio
        </a>
      </div>
    </div>
  );
};

export default NotFoundPage;
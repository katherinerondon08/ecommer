const businessData = [
  {
    id: 1,
    name: "Panadería Doña Rosa",
    category: "Alimentos",
    products: 15,
    joined: "2023-10-15",
    status: "active",
    revenue: 12500
  },
  {
    id: 2,
    name: "Artesanías El Buen Pastor",
    category: "Artesanías",
    products: 42,
    joined: "2023-09-01",
    status: "active",
    revenue: 28700
  },
  {
    id: 3,
    name: "Frutas y Verduras Frescas",
    category: "Alimentos",
    products: 28,
    joined: "2023-11-05",
    status: "pending",
    revenue: 8500
  }
];

export default businessData;
import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, FlatList, Image } from 'react-native';

const AffiliateApp = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [products] = useState([
    { id: '1', name: 'Set de Cocina Artesanal', commission: '15%', price: '$450', image: require('./assets/product1.jpg') },
    { id: '2', name: 'Miel Orgánica 500g', commission: '20%', price: '$180', image: require('./assets/product2.jpg') },
    { id: '3', name: 'Bolso Tejido a Mano', commission: '25%', price: '$320', image: require('./assets/product3.jpg') }
  ]);

  const [earnings] = useState([
    { month: 'Enero', amount: 1250 },
    { month: 'Febrero', amount: 1870 },
    { month: 'Marzo', amount: 2430 }
  ]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Mi Red de Afiliados</Text>
        <View style={styles.balanceContainer}>
          <Text style={styles.balanceLabel}>Saldo Disponible</Text>
          <Text style={styles.balanceAmount}>$5,430</Text>
        </View>
      </View>

      <View style={styles.tabBar}>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'dashboard' && styles.activeTab]}
          onPress={() => setActiveTab('dashboard')}
        >
          <Text style={styles.tabText}>Inicio</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'products' && styles.activeTab]}
          onPress={() => setActiveTab('products')}
        >
          <Text style={styles.tabText}>Productos</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={[styles.tabButton, activeTab === 'stats' && styles.activeTab]}
          onPress={() => setActiveTab('stats')}
        >
          <Text style={styles.tabText}>Estadísticas</Text>
        </TouchableOpacity>
      </View>

      {activeTab === 'dashboard' && (
        <View style={styles.content}>
          <View style={styles.card}>
            <Text style={styles.cardTitle}>Comparte y Gana</Text>
            <Text style={styles.cardText}>Invita a amigos y gana comisiones por cada venta generada a través de tu enlace único</Text>
            <TouchableOpacity style={styles.shareButton}>
              <Text style={styles.shareButtonText}>Compartir Enlace</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.sectionTitle}>Productos Destacados</Text>
          <FlatList
            horizontal
            data={products}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <View style={styles.productCard}>
                <Image source={item.image} style={styles.productImage} />
                <Text style={styles.productName}>{item.name}</Text>
                <Text style={styles.productPrice}>{item.price}</Text>
                <Text style={styles.productCommission}>Gana {item.commission}</Text>
                <TouchableOpacity style={styles.productButton}>
                  <Text style={styles.productButtonText}>Promocionar</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        </View>
      )}

      {activeTab === 'products' && (
        <View style={styles.content}>
          <FlatList
            data={products}
            keyExtractor={item => item.id}
            renderItem={({ item }) => (
              <View style={styles.productRow}>
                <Image source={item.image} style={styles.productRowImage} />
                <View style={styles.productInfo}>
                  <Text style={styles.productRowName}>{item.name}</Text>
                  <Text style={styles.productRowPrice}>{item.price}</Text>
                  <Text style={styles.productRowCommission}>Comisión: {item.commission}</Text>
                </View>
                <TouchableOpacity style={styles.promoteButton}>
                  <Text style={styles.promoteButtonText}>+</Text>
                </TouchableOpacity>
              </View>
            )}
          />
        </View>
      )}

      {activeTab === 'stats' && (
        <View style={styles.content}>
          <View style={styles.statsCard}>
            <Text style={styles.statsTitle}>Mis Ganancias</Text>
            <FlatList
              data={earnings}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item }) => (
                <View style={styles.earningItem}>
                  <Text style={styles.earningMonth}>{item.month}</Text>
                  <Text style={styles.earningAmount}>${item.amount}</Text>
                </View>
              )}
            />
            <View style={styles.totalEarnings}>
              <Text style={styles.totalText}>Total:</Text>
              <Text style={styles.totalAmount}>$5,550</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8f9fa'
  },
  header: {
    backgroundColor: '#4f46e5',
    padding: 20,
    paddingTop: 50,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  headerTitle: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 15
  },
  balanceContainer: {
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 10,
    padding: 15
  },
  balanceLabel: {
    color: 'white',
    fontSize: 14,
    marginBottom: 5
  },
  balanceAmount: {
    color: 'white',
    fontSize: 24,
    fontWeight: 'bold'
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: 'white',
    marginHorizontal: 15,
    marginTop: -15,
    borderRadius: 10,
    elevation: 3,
    overflow: 'hidden'
  },
  tabButton: {
    flex: 1,
    padding: 15,
    alignItems: 'center'
  },
  activeTab: {
    borderBottomWidth: 3,
    borderBottomColor: '#4f46e5'
  },
  tabText: {
    color: '#4f46e5',
    fontWeight: '600'
  },
  content: {
    flex: 1,
    padding: 15
  },
  card: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    elevation: 2
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#1f2937'
  },
  cardText: {
    fontSize: 14,
    color: '#6b7280',
    marginBottom: 15
  },
  shareButton: {
    backgroundColor: '#4f46e5',
    padding: 12,
    borderRadius: 8,
    alignItems: 'center'
  },
  shareButtonText: {
    color: 'white',
    fontWeight: '600'
  },
  sectionTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 15
  },
  productCard: {
    width: 160,
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    marginRight: 15,
    elevation: 2
  },
  productImage: {
    width: '100%',
    height: 120,
    borderRadius: 8,
    marginBottom: 10
  },
  productName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 5
  },
  productPrice: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4f46e5',
    marginBottom: 5
  },
  productCommission: {
    fontSize: 12,
    color: '#10b981',
    marginBottom: 10
  },
  productButton: {
    backgroundColor: '#e0e7ff',
    padding: 8,
    borderRadius: 6,
    alignItems: 'center'
  },
  productButtonText: {
    color: '#4f46e5',
    fontSize: 12,
    fontWeight: '600'
  },
  productRow: {
    flexDirection: 'row',
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 15,
    marginBottom: 15,
    elevation: 1,
    alignItems: 'center'
  },
  productRowImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 15
  },
  productInfo: {
    flex: 1
  },
  productRowName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1f2937',
    marginBottom: 3
  },
  productRowPrice: {
    fontSize: 14,
    color: '#4f46e5',
    marginBottom: 3
  },
  productRowCommission: {
    fontSize: 12,
    color: '#6b7280'
  },
  promoteButton: {
    backgroundColor: '#4f46e5',
    width: 30,
    height: 30,
    borderRadius: 15,
    justifyContent: 'center',
    alignItems: 'center'
  },
  promoteButtonText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold'
  },
  statsCard: {
    backgroundColor: 'white',
    borderRadius: 12,
    padding: 20,
    elevation: 2
  },
  statsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 15
  },
  earningItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb'
  },
  earningMonth: {
    fontSize: 14,
    color: '#1f2937'
  },
  earningAmount: {
    fontSize: 14,
    fontWeight: '600',
    color: '#10b981'
  },
  totalEarnings: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 15,
    paddingTop: 15,
    borderTopWidth: 1,
    borderTopColor: '#e5e7eb'
  },
  totalText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1f2937'
  },
  totalAmount: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#4f46e5'
  }
});

export default AffiliateApp;